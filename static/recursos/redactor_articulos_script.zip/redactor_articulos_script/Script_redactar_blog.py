#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# ===================================================================================
# SCRIPT GENERADOR DE ARTÍCULOS SEO - PLANTILLA PARA AGENCIAS
# ===================================================================================
# Preparado por: Gema Calderón Sayoux (gemacalderonsayoux.com)
# Versión: 1.0
#
# INSTRUCCIONES PARA LA AGENCIA:
# 1. Asegúrate de tener Python instalado.
# 2. Instala las librerías necesarias ejecutando en tu terminal:
#    pip install pandas requests beautifulsoup4
# 3. Personaliza TODO en la sección "CONFIGURACIÓN PRINCIPAL".
# 4. Edita el contenido dentro de las funciones "generar_...()" para escribir tu artículo.
# 5. Modifica la "estructura_articulo" para organizar las secciones a tu gusto.
# 6. Ejecuta el script. Se generará un archivo HTML con tu artículo.
# ===================================================================================

import pandas as pd
import requests
from bs4 import BeautifulSoup
import re

# ===================================================================================
#               ¡CONFIGURACIÓN PRINCIPAL! RELLENA Y ADAPTA TODO AQUÍ
# ===================================================================================

# --- 1. DATOS BÁSICOS DEL ARTÍCULO ---
CONFIGURACION_ARTICULO = {
    # El título que aparecerá en la pestaña del navegador y en los resultados de Google (idealmente < 60 caracteres).
    "SEO_TITLE": "[Escribe aquí el Título SEO del artículo]",

    # La descripción para los resultados de Google (idealmente < 155 caracteres).
    "SEO_META_DESCRIPTION": "[Escribe aquí la Meta Descripción SEO]",

    # El encabezado principal que verán los usuarios en la página.
    "H1_PRINCIPAL": "[Escribe aquí el Encabezado H1 del artículo]",
    
    # (Opcional) Si quieres reutilizar contenido de una página existente, pon la URL aquí.
    # Si no, déjalo en blanco: ""
    "URL_A_SCRAPEAR": "",

    # (Importante si usas la URL de arriba) El selector CSS del contenedor principal del contenido.
    # Debes inspeccionar la web de origen para encontrarlo. '.entry-content' es común en WordPress.
    "SELECTOR_CSS_CONTENIDO": "div.entry-content",

    # El nombre que tendrá el archivo HTML generado.
    "NOMBRE_ARCHIVO_SALIDA": "mi_nuevo_articulo.html"
}

# ===================================================================================
#    FUNCIONES PARA GENERAR EL CONTENIDO DE CADA SECCIÓN (¡AQUÍ ESCRIBES TÚ!)
# ===================================================================================

def generar_introduccion():
    """Crea el párrafo introductorio del artículo."""
    return (
        "<p>[Escribe aquí el párrafo de introducción. Debe ser atractivo y enganchar al lector desde el principio, presentando el problema o la temática que se va a abordar.]</p>"
    )

def generar_seccion_1():
    """Crea una sección de contenido con un encabezado H3 y párrafos."""
    return (
        "<h3>[Escribe aquí un subtítulo H3 para esta sección]</h3>"
        "<p>[Escribe aquí el primer párrafo de esta sección. Desarrolla la idea principal del H3.]</p>"
        "<ul>"
        "<li><strong>Elemento 1:</strong> [Descripción del primer punto de la lista.]</li>"
        "<li><strong>Elemento 2:</strong> [Descripción del segundo punto de la lista.]</li>"
        "<li><strong>Elemento 3:</strong> [Descripción del tercer punto de la lista.]</li>"
        "</ul>"
        "<p><em>[Escribe aquí un párrafo de cierre para la sección, quizás con una reflexión o transición.]</em></p>"
    )

def generar_seccion_con_tabla():
    """Crea una tabla comparativa. Ideal para "Producto A vs Producto B"."""
    return (
        "<p>[Introduce aquí el contexto de la tabla. Por ejemplo: 'Para ayudarte a decidir, hemos preparado una tabla comparando las características clave...']</p>"
        # Edita los encabezados y el contenido de la tabla según tus necesidades.
        # Puedes añadir o quitar filas <tr>...</tr> como necesites.
        '<table style="width:100%; border-collapse: collapse;">'
        '<tr style="background-color:#f2f2f2;">'
        '<th style="padding: 8px; border: 1px solid #ddd; text-align: left;">[Característica]</th>'
        '<th style="padding: 8px; border: 1px solid #ddd; text-align: left;">[Opción A]</th>'
        '<th style="padding: 8px; border: 1px solid #ddd; text-align: left;">[Opción B]</th>'
        '</tr>'
        '<tr>'
        '<td style="padding: 8px; border: 1px solid #ddd;">[Característica 1]</td>'
        '<td style="padding: 8px; border: 1px solid #ddd;"><strong>[Valor para la Opción A]</strong></td>'
        '<td style="padding: 8px; border: 1px solid #ddd;">[Valor para la Opción B]</td>'
        '</tr>'
        '<tr>'
        '<td style="padding: 8px; border: 1px solid #ddd;">[Característica 2]</td>'
        '<td style="padding: 8px; border: 1px solid #ddd;">[Valor para la Opción A]</td>'
        '<td style="padding: 8px; border: 1px solid #ddd;">[Valor para la Opción B]</td>'
        '</tr>'
        '</table>'
        "<p>[Añade un párrafo final que analice o resuma las conclusiones de la tabla.]</p>"
    )

def generar_seccion_personalizada():
    """Una sección genérica que puedes adaptar como quieras."""
    return (
        "<h3>[Escribe aquí otro subtítulo H3]</h3>"
        "<p>[Desarrolla aquí otro punto importante de tu artículo. Puedes hablar de beneficios, casos de uso, consejos prácticos, etc. Sé tan creativo como quieras.]</p>"
    )

def generar_conclusion():
    """Crea la conclusión y la llamada a la acción (CTA)."""
    return (
        "<p>[Escribe aquí el párrafo de conclusión. Resume los puntos más importantes del artículo y refuerza el mensaje principal.]</p>"
        "<p><strong>[Esta es tu llamada a la acción (CTA). Anima al lector a dar el siguiente paso: contactar, comprar, suscribirse, etc.]</strong></p>"
    )


# ===================================================================================
#    SCRIPT PRINCIPAL (NORMALMENTE NO NECESITAS MODIFICAR ESTO)
# ===================================================================================

def scrape_base_content(url, selector):
    """(Función auxiliar) Extrae contenido de una URL si se ha proporcionado."""
    if not url:
        return ""
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
        response = requests.get(url, headers=headers)
        response.raise_for_status()

        soup = BeautifulSoup(response.content, 'html.parser')
        content_div = soup.select_one(selector)
        
        if not content_div:
            return f"<p><i>[Nota del script: No se pudo extraer contenido usando el selector '{selector}'.]</i></p>"

        # Limpieza básica del contenido extraído
        for ad_div in content_div.find_all(class_=re.compile(r'sharedaddy|ad|promo')):
            ad_div.decompose()
        article_html = re.sub(r'\s{2,}', ' ', str(content_div))
        
        return article_html
    except requests.exceptions.RequestException as e:
        return f"<p><i>[Nota del script: Error al hacer scraping de la URL base: {e}.]</i></p>"


def ensamblar_articulo():
    """
    Función principal que construye el artículo completo basado en tu configuración.
    """
    print("Iniciando la creación del artículo...")
    
    # --- ESTRUCTURA DEL ARTÍCULO: ¡Organiza las secciones a tu gusto! ---
    # Puedes reordenar, duplicar o eliminar bloques de esta lista para cambiar el flujo del artículo.
    # Por ejemplo, puedes añadir otro {'tipo': 'Seccion H2', 'contenido': 'Otro Gran Tema'}
    # seguido de {'tipo': 'Parrafo', 'contenido': generar_seccion_personalizada()}
    
    estructura_articulo = [
        {'tipo': 'SEO Title', 'contenido': CONFIGURACION_ARTICULO['SEO_TITLE']},
        {'tipo': 'SEO Meta Description', 'contenido': CONFIGURACION_ARTICULO['SEO_META_DESCRIPTION']},
        {'tipo': 'Titulo H1', 'contenido': CONFIGURACION_ARTICULO['H1_PRINCIPAL']},
        {'tipo': 'Introduccion', 'contenido': generar_introduccion()},
        
        # Esta sección solo aparecerá si has definido una URL para scrapear.
        {'tipo': 'Contenido Scrapeado', 'contenido': scrape_base_content(CONFIGURACION_ARTICULO['URL_A_SCRAPEAR'], CONFIGURACION_ARTICULO['SELECTOR_CSS_CONTENIDO'])},
        
        {'tipo': 'Titulo H2', 'contenido': '[Escribe aquí el primer encabezado H2]'},
        {'tipo': 'Parrafo', 'contenido': generar_seccion_1()},
        
        {'tipo': 'Titulo H2', 'contenido': '[Escribe aquí el segundo encabezado H2, ej: Comparativa]'},
        {'tipo': 'Parrafo', 'contenido': generar_seccion_con_tabla()},
        
        {'tipo': 'Titulo H2', 'contenido': '[Escribe aquí el tercer encabezado H2]'},
        {'tipo': 'Parrafo', 'contenido': generar_seccion_personalizada()},
        
        {'tipo': 'Titulo H2', 'contenido': 'Conclusión: [Resume la idea final]'},
        {'tipo': 'Conclusion', 'contenido': generar_conclusion()}
    ]
    
    # Filtra el contenido scrapeado si está vacío
    estructura_final = [sec for sec in estructura_articulo if sec.get('contenido')]
    
    print("Estructura definida. Creando el DataFrame...")
    df = pd.DataFrame(estructura_final)
    
    print("¡Proceso completado! El DataFrame del artículo está listo.")
    return df


def exportar_a_html(df, filename):
    """Genera el archivo HTML final a partir del DataFrame."""
    if df.empty:
        print("El DataFrame está vacío. No se generará ningún archivo.")
        return

    html_output = ""
    for index, row in df.iterrows():
        tipo = row['tipo']
        contenido = row['contenido']
        
        if tipo == 'Titulo H1':
            html_output += f"<h1>{contenido}</h1>\n"
        elif tipo == 'Titulo H2':
            html_output += f"<h2>{contenido}</h2>\n"
        # El resto de tipos de contenido ya vienen con sus etiquetas <p>, <h3>, <ul>, etc.
        elif tipo not in ['SEO Title', 'SEO Meta Description']:
            html_output += f"<div>{contenido}</div>\n"
            
    # Estilos CSS básicos para una buena legibilidad
    css_styles = """
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.7; max-width: 800px; margin: auto; padding: 20px; color: #333; } 
        h1, h2, h3 { color: #1a0dab; } 
        h1 { font-size: 2.2em; } 
        h2 { font-size: 1.8em; border-bottom: 2px solid #eee; padding-bottom: 8px; margin-top: 40px;} 
        h3 { font-size: 1.4em; } 
        table { width: 100%; border-collapse: collapse; margin: 20px 0; } 
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; } 
        tr:nth-child(even) { background-color: #f9f9f9; } 
        th { background-color: #f2f2f2; font-weight: bold; }
        code { background-color: #eee; padding: 2px 4px; border-radius: 4px; }
        li { margin-bottom: 8px; }
    </style>
    """
    
    with open(filename, "w", encoding="utf-8") as file:
        file.write("<!DOCTYPE html>\n<html lang='es'>\n<head>\n")
        file.write(f"<title>{df.iloc[0]['contenido']}</title>\n")
        file.write(f"<meta name='description' content='{df.iloc[1]['contenido']}'>\n")
        file.write("<meta charset='UTF-8'>\n")
        file.write(css_styles)
        file.write("</head>\n<body>\n")
        file.write(html_output)
        file.write("</body>\n</html>")

    print(f"\n¡ÉXITO! El artículo ha sido exportado a '{filename}'")


# --- EJECUCIÓN DEL SCRIPT ---
if __name__ == '__main__':
    articulo_df = ensamblar_articulo()
    if not articulo_df.empty:
        print("\n--- Vista Previa del DataFrame del Artículo ---")
        print(articulo_df[['tipo']]) # Mostramos solo los tipos para no saturar la consola
        exportar_a_html(articulo_df, CONFIGURACION_ARTICULO['NOMBRE_ARCHIVO_SALIDA'])

